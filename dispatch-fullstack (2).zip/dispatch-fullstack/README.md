# Dispatch — Internal IT Support Agent (Veridian Corp)

Assignment 2 (Agentic AI Factory): an internal employee-support agent for
IT at a fictional company, Veridian Corp, built from the assignment's
data pack. Full stack: **React** (Vite) frontend, **Node.js/Express**
backend, **SQLite** persistence (Node's built-in `node:sqlite` — no
native module to compile), **Google AI Studio (Gemini)** for the agent's reasoning.

Tested on **Node 24**. Requires Node ≥ 22.5 for `node:sqlite`.

## Run it (development — two terminals)

**Terminal 1 — backend:**
```
cd server
cp .env.example .env      # then paste your Gemini key into .env
npm install
npm run dev
```
Starts the API on `http://localhost:4000` and creates+seeds
`server/data/dispatch.db` on first run.

**Terminal 2 — frontend:**
```
cd client
npm install
npm run dev
```
Opens on `http://localhost:5173` and proxies `/api` to the backend.

## Run it (single command, production-style)

Builds the React app and serves it from the same Express server on one
port — closest to "something a reviewer can open and try themselves":

```
cd server && cp .env.example .env   # add your key
npm install
cd ../client && npm install && npm run build
cd ../server && npm start
```
Then open `http://localhost:4000` — frontend and API on the same port.

`.env` is gitignored in `server/`, so your API key never gets committed.

## What it does

- **Requests** — each of the 15 employee requests from the data pack is a
  live conversation, persisted in SQLite. Dispatch reads the request, the
  full knowledge base, and the current ticket queue, then either:
  - **resolves** it directly from policy (citing the KB item), or
  - **asks one follow-up question** when it doesn't have enough to act
    safely — e.g. a vague "it's not working" — or
  - **opens a ticket**, routed to IT, Security, or Finance, escalating
    anything risky or missing a required approval (it's instructed to
    never grant elevated/admin access itself).
  Where a request was already marked in-progress in the tracker (e.g.
  "waiting on Security review"), Dispatch reports that status instead of
  duplicating work. Refreshing the browser keeps everything — it's a
  real database, not in-memory state.
- **Ticket Queue** — the original 10 tickets (TK-1042–TK-1051) plus every
  ticket Dispatch opens during use, with status and the source that
  justified each one.
- **Audit Trail** — a timestamped log of every decision Dispatch made
  (action taken, who it was routed to, which KB/ticket IDs it cited),
  exportable as CSV.
- **Knowledge Base** — the KB-01–KB-10 policies and the asset-management
  extract, shown as-is, so a reviewer can check Dispatch's citations
  against the real source.
- **How it works** — a live process-flow diagram plus the written
  assumptions and AI-tools-used sections the brief requires.

## Project structure

```
server/                Express API + SQLite + Gemini calls
  src/
    index.js           app entry, serves client/dist in production
    db.js               node:sqlite setup + one-time seeding
    routes.js           REST endpoints
    llm.js               Gemini call + JSON parsing
    promptBuilder.js     builds the grounded routing prompt
    data/seed.js          KB, asset policy, seeded requests & tickets
  .env.example
client/                 React (Vite) frontend
  src/
    App.jsx              tabs + theme toggle
    api.js                fetch wrapper for the backend
    components/           Requests / Tickets / Audit / KB / How-it-works
```

## Architecture

```
Employee request (tracker seed, or typed live)
        │
        ▼
Dispatch reads: issue + KB + asset policy + ticket queue (precedent)
        │
        ▼
   Enough to act on safely and correctly?
        │
   ┌────┴────┐
  no          yes
   │           │
Ask ONE      policy covers it ──► Resolve directly, cite KB source(s)
follow-up         │
question     needs human action
   │               │
   └──loop──   risky / unclear / missing approval?
                    │
              ┌─────┴─────┐
             no           yes
              │             │
        Create IT ticket   Escalate to Security/Finance + ticket
              │             │
              └──── Audit trail entry (SQLite) ────┘
```

(The in-app "How it works" tab renders this as a live diagram.)

## Inputs, sources & assumptions

- **Inputs**: the Veridian Corp data pack — 10 knowledge-base policies
  (KB-01–KB-10), one asset-management policy extract, 15 seeded employee
  requests with their prior status, and the existing 10-ticket queue
  (TK-1042–TK-1051), all seeded into SQLite on first run. "New request"
  in the UI lets a reviewer add a live case on top of these.
- **Grounding rule**: Dispatch is instructed to answer only from that
  data, and to say so — then ask or escalate — when nothing in it covers
  the request, rather than inventing a policy.
- **Precedent**: the full ticket queue is passed to the model on every
  call so Dispatch can match a new case against a similar past one (e.g.
  an admin-access request against TK-1050, rejected for lacking business
  justification) instead of deciding from scratch each time.
- **In-progress requests**: where the tracker already shows a status
  ("in progress", "waiting on…"), Dispatch reports that status rather
  than reopening or duplicating the case, unless the employee adds new
  information.
- **Assumption**: Dispatch never grants elevated or admin access itself —
  anything of that kind is routed to Security or Finance with a stated
  reason, matching how TK-1050 was actually handled.
- **Assumption**: one SQLite file (`server/data/dispatch.db`) is the
  whole system of record — no multi-tenant/auth concerns for this
  prototype; the "New request" form has no login, matching the
  assignment's clickable-prototype scope.

## AI tools used & how

- **Google AI Studio (Gemini API, `gemini-2.5-flash` by default,
  configurable via `GEMINI_MODEL` in `.env`)** is the whole decision
  layer: given the employee's message, the full KB/policy text, and the
  ticket queue, it decides whether to resolve, ask a follow-up, or open
  a ticket — and if a ticket, whether to escalate and to whom.
- **Structured output**: every call sets `generationConfig.
  responseMimeType: "application/json"` and returns strict JSON (reply
  text, action, escalate flag, assigned team, priority, cited sources,
  an internal audit note), so the server can act on it deterministically
  and every decision traces to a specific KB or ticket ID rather than
  free prose.
- **Ticket IDs and status text are assigned by the server**, not the
  model, so numbering stays consistent with the existing TK-1042+
  sequence and can't be spoofed by a model response.
- **No fine-tuning or vector search** — the whole knowledge base and
  ticket queue are small enough to pass in full on every call, which
  also makes "show the source used" a matter of citing an ID rather than
  a retrieval step that could silently miss something.
- **Built with:** this app — the database schema, the routing prompt and
  JSON contract, the Express API, and the React interface — was built
  with Claude (Anthropic), in a chat conversation, starting from photos
  of the assignment's data pack.

## Still needed for submission

- Push this repo to GitHub.
- Record the 15-minute demo/defence video, and a demo video on Drive
  with open access.
- Turn the architecture/assumptions/tools sections above into the
  10-slide deck.

## Troubleshooting

- **`node:sqlite` errors on startup**: you need Node ≥ 22.5. On Node
  22–23 you may see `ExperimentalWarning: SQLite is an experimental
  feature` printed to the console — that's expected and harmless. On
  Node 24 this is unflagged.
- **"No Gemini key configured" in the UI**: copy `server/.env.example`
  to `server/.env`, add your key (free at
  https://aistudio.google.com/apikey), and restart the server
  (`npm run dev` / `npm start`).
- **429 / quota errors from Gemini**: Google AI Studio's free tier has
  per-minute and per-day request limits that vary by model — if you hit
  them, wait a bit, switch `GEMINI_MODEL` to a lower-tier model in
  `.env`, or attach billing in Google AI Studio for higher limits.
- **Frontend can't reach the API in dev mode**: make sure the backend
  (`server`, port 4000) is running before or alongside `npm run dev` in
  `client` — Vite's dev server proxies `/api` to it.
