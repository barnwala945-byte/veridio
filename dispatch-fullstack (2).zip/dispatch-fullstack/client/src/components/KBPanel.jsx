import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function KBPanel() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    api.getKB().then(setItems).catch(() => {});
  }, []);

  return (
    <>
      <div className="toolbar">
        <h2>Knowledge Base</h2>
        <span className="count-note">The only source Dispatch is allowed to answer from</span>
      </div>
      <div>
        {items.map((k) => (
          <div className="kb-item" key={k.id}>
            <span className="kid">{k.id}</span>
            <span className="kt">{k.title}</span>
            <p>{k.text}</p>
          </div>
        ))}
      </div>
    </>
  );
}
