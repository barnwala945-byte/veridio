import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function TicketsPanel() {
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    api.getTickets().then(setTickets).catch(() => {});
  }, []);

  const openCount = tickets.filter((t) => t.open).length;

  return (
    <>
      <div className="toolbar">
        <h2>Ticket Queue</h2>
        <span className="count-note">{tickets.length} tickets · {openCount} open</span>
      </div>
      <div className="card table-scroll">
        <table>
          <thead>
            <tr><th>Ticket</th><th>Employee</th><th>Issue</th><th>Assigned</th><th>Status</th><th>Source</th></tr>
          </thead>
          <tbody>
            {tickets.map((t) => (
              <tr key={t.id}>
                <td style={{ fontFamily: "'IBM Plex Mono',monospace" }}>{t.id}</td>
                <td>{t.employee}</td>
                <td>{t.issue}</td>
                <td>{t.assigned}</td>
                <td><span className={`pill ${t.escalated ? 'escalated' : (t.open ? 'open' : 'closed')}`}>{t.status}</span></td>
                <td>{(t.sources || []).join(', ') || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
