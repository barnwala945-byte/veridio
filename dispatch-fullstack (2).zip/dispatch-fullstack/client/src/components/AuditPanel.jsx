import { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function AuditPanel() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    api.getAudit().then(setRows).catch(() => {});
  }, []);

  return (
    <>
      <div className="toolbar">
        <h2>Audit Trail</h2>
        <a className="btn secondary" href={api.auditCsvUrl()} style={{ textDecoration: 'none', display: 'inline-block' }}>Export CSV</a>
      </div>
      <div className="card table-scroll">
        <table>
          <thead>
            <tr><th>Time</th><th>Request</th><th>Employee</th><th>Action</th><th>Routed to</th><th>Sources</th><th>Note</th></tr>
          </thead>
          <tbody>
            {rows.map((a) => (
              <tr key={a.id}>
                <td style={{ fontFamily: "'IBM Plex Mono',monospace", whiteSpace: 'nowrap' }}>{new Date(a.time).toLocaleString()}</td>
                <td>{a.req_id}</td>
                <td>{a.employee}</td>
                <td>{a.action}</td>
                <td>{a.routed_to}</td>
                <td>{a.sources}</td>
                <td>{a.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
