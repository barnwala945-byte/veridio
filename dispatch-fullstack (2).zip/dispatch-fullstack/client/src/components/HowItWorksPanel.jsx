import { useEffect, useRef } from 'react';
import mermaid from 'mermaid';

const DIAGRAM = `flowchart LR
  A["Employee request\n(tracker seed, or typed live)"] --> B["Dispatch reads:\nissue + KB + asset policy\n+ ticket queue (precedent)"]
  B --> C{"Enough to act on\nsafely and correctly?"}
  C -->|"no"| D["Ask ONE focused\nfollow-up question"]
  D --> B
  C -->|"yes, policy covers it"| E["Resolve directly\ncite KB source(s)"]
  C -->|"yes, needs human action"| F{"Risky / unclear /\nmissing approval?"}
  F -->|"no"| G["Create IT ticket\ncite KB source(s)"]
  F -->|"yes"| H["Escalate to Security\nor Finance + ticket"]
  E --> I["Audit trail entry\n(SQLite)"]
  G --> I
  H --> I`;

let mermaidReady = false;
function ensureMermaid() {
  if (!mermaidReady) {
    mermaid.initialize({
      startOnLoad: false, theme: 'dark', securityLevel: 'loose',
      themeVariables: {
        background: '#1D2531', primaryColor: '#26303F', primaryTextColor: '#F2EFE6',
        primaryBorderColor: '#333F4F', lineColor: '#7C8794', secondaryColor: '#26303F', tertiaryColor: '#1D2531',
      },
    });
    mermaidReady = true;
  }
}

export default function HowItWorksPanel() {
  const ref = useRef(null);

  useEffect(() => {
    ensureMermaid();
    let cancelled = false;
    mermaid.render('dispatch-flow', DIAGRAM).then(({ svg }) => {
      if (!cancelled && ref.current) ref.current.innerHTML = svg;
    });
    return () => { cancelled = true; };
  }, []);

  return (
    <>
      <div className="card">
        <h3>Process flow</h3>
        <div className="mermaid-box" ref={ref} />
      </div>

      <div className="hiw-grid">
        <div className="card">
          <h3>Inputs, sources &amp; assumptions</h3>
          <ul>
            <li><strong>Inputs:</strong> the Veridian Corp data pack — 10 knowledge-base policies (KB-01–KB-10), one asset-management policy extract, 15 seeded employee requests with their prior status, and the existing 10-ticket queue (TK-1042–TK-1051), all seeded into SQLite on first run. The "New request" form lets a reviewer add a live case on top of these.</li>
            <li><strong>Grounding rule:</strong> Dispatch is instructed to answer only from that data, and to say so — then ask or escalate — when nothing in it covers the request, rather than inventing a policy.</li>
            <li><strong>Precedent:</strong> the full ticket queue is passed in on every call so Dispatch can match a new case against a similar past one (e.g. an admin-access request against TK-1050, rejected for lacking business justification) instead of deciding from scratch each time.</li>
            <li><strong>In-progress requests:</strong> where the tracker already shows a status ("in progress", "waiting on…"), Dispatch reports that status rather than reopening or duplicating the case, unless the employee adds new information.</li>
            <li><strong>Assumption:</strong> Dispatch never grants elevated or admin access itself — anything of that kind is routed to Security or Finance with a stated reason, matching how TK-1050 was actually handled.</li>
          </ul>
        </div>
        <div className="card">
          <h3>AI tools used &amp; how</h3>
          <ul>
            <li><strong>Google AI Studio (Gemini API, <code>gemini-2.5-flash</code> by default, configurable)</strong> is the whole decision layer: given the employee's message, the full KB/policy text, and the ticket queue, it decides whether to resolve, ask a follow-up, or open a ticket — and if a ticket, whether to escalate and to whom.</li>
            <li><strong>Structured output:</strong> every call sets <code>responseMimeType: "application/json"</code> and returns strict JSON (reply text, action, escalate flag, assigned team, priority, cited sources, an internal audit note), so the UI renders deterministically and every action traces to a specific KB or ticket ID.</li>
            <li><strong>Ticket IDs and status text are assigned by the server</strong>, not the model, so numbering stays consistent with the existing TK-1042+ sequence — stored in SQLite via Node's built-in <code>node:sqlite</code> module.</li>
            <li><strong>No fine-tuning or vector search</strong> — the whole knowledge base and ticket queue are small enough to pass in full on every call, which also makes "show the source used" a matter of citing an ID rather than a retrieval step that could silently miss something.</li>
            <li><strong>Built with:</strong> this app — server, database schema, prompt, and React interface — was built with Claude (Anthropic), in a chat conversation, starting from photos of the assignment's data pack.</li>
          </ul>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <h3>Still needed for submission</h3>
        <ul style={{ margin: 0, paddingLeft: 18, color: 'var(--ink-dim)', fontSize: 13 }}>
          <li>Push this repo to GitHub and record the 15-minute demo/defence, plus a demo video on Drive with open access.</li>
          <li>Turn this tab's process flow, assumptions and tool list into the 10-slide deck.</li>
        </ul>
      </div>
    </>
  );
}
