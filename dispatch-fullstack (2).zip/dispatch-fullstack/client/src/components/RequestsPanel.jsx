import { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';

function reqStatusClass(req) {
  if (req.resolved) return 'done';
  if (req.messages.some((m) => m.escalate)) return 'risk';
  if (req.messages.length) return 'open';
  return '';
}
function reqStatusLabel(req) {
  const last = [...req.messages].reverse().find((m) => m.role === 'agent');
  if (last) {
    if (last.action === 'resolve') return 'resolved';
    if (last.action === 'ticket') return last.escalate ? 'escalated' : 'ticketed';
    if (last.action === 'clarify') return 'awaiting reply';
  }
  return req.initial && req.initial.toLowerCase().includes('not started') ? 'not started' : (req.initial || '').toLowerCase();
}

export default function RequestsPanel({ onKeyMissing }) {
  const [requests, setRequests] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [loadingReply, setLoadingReply] = useState(false);
  const [input, setInput] = useState('');
  const [showNewForm, setShowNewForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newText, setNewText] = useState('');
  const logRef = useRef(null);
  const startedRef = useRef(new Set());

  useEffect(() => {
    api.getRequests().then(setRequests).catch(() => {});
  }, []);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [activeId, requests]);

  function updateRequest(updated) {
    setRequests((prev) => prev.map((r) => (r.id === updated.id ? { ...r, ...updated } : r)));
  }

  function checkKeyMissing(req) {
    const bad = req.messages.some((m) => m.role === 'agent' && /GEMINI_API_KEY is not set/.test(m.text));
    if (bad) onKeyMissing(true);
  }

  async function openRequest(id) {
    setActiveId(id);
    const req = requests.find((r) => r.id === id);
    if (req && req.messages.length === 0 && !startedRef.current.has(id)) {
      startedRef.current.add(id);
      setLoadingReply(true);
      try {
        const updated = await api.sendMessage(id, req.text);
        updateRequest(updated);
        checkKeyMissing(updated);
      } finally {
        setLoadingReply(false);
      }
    }
  }

  async function sendFollowUp() {
    const text = input.trim();
    if (!text || !activeId) return;
    setInput('');
    setLoadingReply(true);
    try {
      const updated = await api.sendMessage(activeId, text);
      updateRequest(updated);
      checkKeyMissing(updated);
    } finally {
      setLoadingReply(false);
    }
  }

  async function submitNewRequest() {
    const text = newText.trim();
    if (!text) return;
    const created = await api.createRequest(newName.trim() || 'Anonymous employee', text);
    setRequests((prev) => [...prev, created]);
    setNewName(''); setNewText(''); setShowNewForm(false);
    openRequest(created.id);
  }

  const active = requests.find((r) => r.id === activeId) || null;
  const activeTicketId = active
    ? (active.messages.find((m) => m.action === 'ticket') ? 'ticket created — see Ticket Queue' : null)
    : null;

  return (
    <div className="req-layout">
      <div>
        <button className="btn secondary" type="button" style={{ width: '100%', marginBottom: 10 }}
          onClick={() => setShowNewForm((s) => !s)}>
          + New request
        </button>
        {showNewForm && (
          <div className="new-req-form">
            <input placeholder="Employee name" value={newName} onChange={(e) => setNewName(e.target.value)} />
            <textarea placeholder="Type the request as the employee would write it…" value={newText} onChange={(e) => setNewText(e.target.value)} />
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn" type="button" onClick={submitNewRequest}>Send</button>
              <button className="btn secondary" type="button" onClick={() => setShowNewForm(false)}>Cancel</button>
            </div>
          </div>
        )}
        <div className="req-list">
          {requests.map((r) => (
            <div
              key={r.id}
              className={`req-row ${reqStatusClass(r)} ${r.id === activeId ? 'active' : ''}`}
              onClick={() => openRequest(r.id)}
            >
              <div className="rid">{r.id}</div>
              <div className="name">{r.name}</div>
              <div className="snip">{r.text}</div>
              <span className="st">{reqStatusLabel(r)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="thread-card">
        <div className="thread-head">
          <div>
            <div className="who">{active ? active.name : 'Select a request'}</div>
            <div className="sub">{active ? `${active.id} · ${active.email || 'no email on file'} · opened ${active.date}` : ''}</div>
          </div>
          {activeTicketId && <span className="badge">{activeTicketId}</span>}
        </div>
        <div className="thread-log" ref={logRef}>
          {!active && (
            <div className="thread-empty">Pick a request on the left — Dispatch will read it against Veridian's IT knowledge base and respond.</div>
          )}
          {active && active.messages.map((m) => (
            <div key={m.id} className={`msg ${m.role === 'employee' ? 'employee' : 'agent'}`}>
              {m.role === 'agent' && <span className="who-label">DISPATCH</span>}
              <div>{m.text}</div>
              {m.role === 'agent' && m.action && (
                <div className="badges">
                  <span className={`badge ${m.action === 'resolve' ? 'act-resolve' : m.action === 'clarify' ? 'act-clarify' : (m.escalate ? 'act-escalate' : 'act-ticket')}`}>
                    {m.escalate ? 'escalated' : m.action}
                  </span>
                  {(m.sources || []).map((s) => <span key={s} className="badge">{s}</span>)}
                  {m.assignedTo && <span className="badge">→ {m.assignedTo}</span>}
                </div>
              )}
            </div>
          ))}
          {loadingReply && (
            <div className="msg agent"><span className="who-label">DISPATCH</span><div>Thinking…</div></div>
          )}
        </div>
        <div className="thread-input-row">
          <input
            placeholder="Reply as the employee…"
            disabled={!active || loadingReply}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') sendFollowUp(); }}
          />
          <button className="btn" type="button" disabled={!active || loadingReply} onClick={sendFollowUp}>Send</button>
        </div>
      </div>
    </div>
  );
}
