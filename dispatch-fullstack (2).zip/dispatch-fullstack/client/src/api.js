const BASE = '/api';

async function j(res) {
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  getKB: () => fetch(`${BASE}/kb`).then(j),
  getRequests: () => fetch(`${BASE}/requests`).then(j),
  getRequest: (id) => fetch(`${BASE}/requests/${id}`).then(j),
  createRequest: (name, text) =>
    fetch(`${BASE}/requests`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name, text }),
    }).then(j),
  sendMessage: (id, text) =>
    fetch(`${BASE}/requests/${id}/messages`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ text }),
    }).then(j),
  getTickets: () => fetch(`${BASE}/tickets`).then(j),
  getAudit: () => fetch(`${BASE}/audit`).then(j),
  auditCsvUrl: () => `${BASE}/audit/export.csv`,
};
