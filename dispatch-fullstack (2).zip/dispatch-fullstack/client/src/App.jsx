import { useEffect, useState } from 'react';
import RequestsPanel from './components/RequestsPanel.jsx';
import TicketsPanel from './components/TicketsPanel.jsx';
import AuditPanel from './components/AuditPanel.jsx';
import KBPanel from './components/KBPanel.jsx';
import HowItWorksPanel from './components/HowItWorksPanel.jsx';

const TABS = [
  { id: 'requests', label: 'Requests' },
  { id: 'tickets', label: 'Ticket Queue' },
  { id: 'audit', label: 'Audit Trail' },
  { id: 'kb', label: 'Knowledge Base' },
  { id: 'hiw', label: 'How it works' },
];

export default function App() {
  const [tab, setTab] = useState('requests');
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('dispatch_theme') || ''; } catch { return ''; }
  });
  const [keyMissing, setKeyMissing] = useState(false);

  useEffect(() => {
    if (theme) document.documentElement.setAttribute('data-theme', theme);
    else document.documentElement.removeAttribute('data-theme');
    try { localStorage.setItem('dispatch_theme', theme); } catch { /* ignore */ }
  }, [theme]);

  function toggleTheme() {
    setTheme((cur) => {
      if (cur === 'dark') return 'light';
      if (cur === 'light') return '';
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'light' : 'dark';
    });
  }

  return (
    <div className="wrap">
      <div className="masthead">
        <div className="brand">
          <h1>Dispatch</h1>
          <div className="tagline">Internal IT support agent — reads each request, resolves what it can from policy, and routes the rest.</div>
        </div>
        <div className="meta-block">
          <div className="co">Veridian Corp · IT</div>
          <div>Internal Service Agent · Assignment&nbsp;2</div>
          <button className="theme-toggle" onClick={toggleTheme} type="button">toggle theme</button>
          {keyMissing && (
            <div className="key-warn">
              The server reports no Gemini key configured — copy server/.env.example to server/.env and add one, then restart the server.
            </div>
          )}
        </div>
      </div>

      <nav className="tabs" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            className={tab === t.id ? 'active' : ''}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <section className="panel" hidden={tab !== 'requests'}>
        <RequestsPanel onKeyMissing={setKeyMissing} />
      </section>
      <section className="panel" hidden={tab !== 'tickets'}>
        {tab === 'tickets' && <TicketsPanel />}
      </section>
      <section className="panel" hidden={tab !== 'audit'}>
        {tab === 'audit' && <AuditPanel />}
      </section>
      <section className="panel" hidden={tab !== 'kb'}>
        {tab === 'kb' && <KBPanel />}
      </section>
      <section className="panel" hidden={tab !== 'hiw'}>
        {tab === 'hiw' && <HowItWorksPanel />}
      </section>

      <footer>DISPATCH — INTERNAL SERVICE AGENT — VERIDIAN CORP IT — PROTOTYPE BUILD</footer>
    </div>
  );
}
