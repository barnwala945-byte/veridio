import { Router } from 'express';
import db, { nextTicketId, nextRequestId } from './db.js';
import { buildPrompt } from './promptBuilder.js';
import { callAgentJSON } from './llm.js';

const router = Router();

function rowToMessage(row) {
  return {
    id: row.id,
    role: row.role,
    text: row.text,
    action: row.action || null,
    escalate: !!row.escalate,
    assignedTo: row.assigned_to || null,
    priority: row.priority || null,
    sources: row.sources ? JSON.parse(row.sources) : [],
    ticketSummary: row.ticket_summary || null,
    auditNote: row.audit_note || null,
    createdAt: row.created_at,
  };
}

function getRequestWithMessages(id) {
  const req = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
  if (!req) return null;
  const messages = db.prepare('SELECT * FROM messages WHERE request_id = ? ORDER BY id ASC').all(id).map(rowToMessage);
  return { ...req, resolved: !!req.resolved, messages };
}

function allTickets() {
  return db.prepare('SELECT * FROM tickets ORDER BY id ASC').all().map((t) => ({
    ...t,
    open: !!t.open,
    escalated: !!t.escalated,
    sources: t.sources ? JSON.parse(t.sources) : [],
  }));
}

// ---------- Knowledge base ----------
router.get('/kb', (req, res) => {
  const rows = db.prepare('SELECT * FROM kb ORDER BY id ASC').all();
  res.json(rows);
});

// ---------- Requests ----------
router.get('/requests', (req, res) => {
  const ids = db.prepare('SELECT id FROM requests ORDER BY id ASC').all().map((r) => r.id);
  res.json(ids.map(getRequestWithMessages));
});

router.get('/requests/:id', (req, res) => {
  const data = getRequestWithMessages(req.params.id);
  if (!data) return res.status(404).json({ error: 'not_found' });
  res.json(data);
});

router.post('/requests', (req, res) => {
  const { name, text } = req.body || {};
  if (!text || !String(text).trim()) return res.status(400).json({ error: 'text_required' });
  const id = nextRequestId();
  db.prepare('INSERT INTO requests (id, name, email, date, text, initial, resolved) VALUES (?, ?, ?, ?, ?, ?, 0)')
    .run(id, (name || 'Anonymous employee').trim(), '', 'live demo', String(text).trim(), 'Not started');
  res.status(201).json(getRequestWithMessages(id));
});

// Post an employee message on a request; runs Dispatch and returns the full
// updated request (including the new employee + agent messages).
router.post('/requests/:id/messages', async (req, res) => {
  const request = db.prepare('SELECT * FROM requests WHERE id = ?').get(req.params.id);
  if (!request) return res.status(404).json({ error: 'not_found' });
  const text = (req.body && req.body.text ? String(req.body.text) : '').trim();
  if (!text) return res.status(400).json({ error: 'text_required' });

  db.prepare('INSERT INTO messages (request_id, role, text) VALUES (?, ?, ?)').run(request.id, 'employee', text);

  const history = db.prepare('SELECT * FROM messages WHERE request_id = ? ORDER BY id ASC').all(request.id).map(rowToMessage);
  const tickets = allTickets();
  const prompt = buildPrompt(request, history, tickets);

  let data;
  try {
    data = await callAgentJSON(prompt);
  } catch (e) {
    db.prepare('INSERT INTO messages (request_id, role, text, action) VALUES (?, ?, ?, ?)')
      .run(request.id, 'agent', `Error: ${e.message || 'could not process this request.'}`, 'clarify');
    return res.status(200).json(getRequestWithMessages(request.id));
  }

  const action = ['resolve', 'clarify', 'ticket'].includes(data.action) ? data.action : 'clarify';
  const sources = Array.isArray(data.sources) ? data.sources : [];

  db.prepare(`INSERT INTO messages
      (request_id, role, text, action, escalate, assigned_to, priority, sources, ticket_summary, audit_note)
      VALUES (?, 'agent', ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(
      request.id,
      data.reply || '(no reply text)',
      action,
      data.escalate ? 1 : 0,
      data.assignedTo || null,
      data.priority || null,
      JSON.stringify(sources),
      data.ticketSummary || null,
      data.auditNote || null
    );

  if (action === 'resolve') {
    db.prepare('UPDATE requests SET resolved = 1 WHERE id = ?').run(request.id);
  }

  let createdTicketId = null;
  if (action === 'ticket') {
    createdTicketId = nextTicketId();
    const assignedTo = data.assignedTo || 'IT';
    const statusText = data.escalate ? `Escalated to ${assignedTo} — pending review` : `Pending ${assignedTo} review`;
    db.prepare(`INSERT INTO tickets
        (id, employee, issue, assigned, status, open, escalated, source_req, sources)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)`)
      .run(createdTicketId, request.name, data.ticketSummary || request.text, assignedTo, statusText, data.escalate ? 1 : 0, request.id, JSON.stringify(sources));
  }

  db.prepare(`INSERT INTO audit (time, req_id, employee, action, routed_to, sources, note) VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(
      new Date().toISOString(),
      request.id,
      request.name,
      data.escalate ? 'escalate' : action,
      data.assignedTo || '—',
      sources.join(', ') || '—',
      data.auditNote || ''
    );

  res.json({ ...getRequestWithMessages(request.id), createdTicketId });
});

// ---------- Tickets ----------
router.get('/tickets', (req, res) => {
  res.json(allTickets());
});

// ---------- Audit trail ----------
router.get('/audit', (req, res) => {
  const rows = db.prepare('SELECT * FROM audit ORDER BY id ASC').all();
  res.json(rows);
});

router.get('/audit/export.csv', (req, res) => {
  const rows = db.prepare('SELECT * FROM audit ORDER BY id ASC').all();
  const header = ['Time', 'Request', 'Employee', 'Action', 'Routed to', 'Sources', 'Note'];
  const csvRows = rows.map((a) => [a.time, a.req_id, a.employee, a.action, a.routed_to, a.sources, a.note]);
  const csv = [header, ...csvRows]
    .map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))
    .join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="dispatch-audit-trail.csv"');
  res.send(csv);
});

export default router;
