import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { mkdirSync, existsSync } from 'node:fs';
import { KB, ASSET_POLICY, SEED_REQUESTS, SEED_TICKETS, FIRST_NEW_TICKET_NUM, FIRST_NEW_REQUEST_NUM } from './data/seed.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', 'data');
if (!existsSync(dataDir)) mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(join(dataDir, 'dispatch.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS kb (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    text TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS requests (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT,
    date TEXT,
    text TEXT NOT NULL,
    initial TEXT,
    resolved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL REFERENCES requests(id),
    role TEXT NOT NULL,
    text TEXT NOT NULL,
    action TEXT,
    escalate INTEGER DEFAULT 0,
    assigned_to TEXT,
    priority TEXT,
    sources TEXT,
    ticket_summary TEXT,
    audit_note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id TEXT PRIMARY KEY,
    employee TEXT NOT NULL,
    issue TEXT NOT NULL,
    assigned TEXT,
    status TEXT,
    open INTEGER NOT NULL DEFAULT 1,
    escalated INTEGER NOT NULL DEFAULT 0,
    source_req TEXT,
    sources TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT NOT NULL,
    req_id TEXT,
    employee TEXT,
    action TEXT,
    routed_to TEXT,
    sources TEXT,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

function getMeta(key, fallback) {
  const row = db.prepare('SELECT value FROM meta WHERE key = ?').get(key);
  return row ? row.value : fallback;
}
function setMeta(key, value) {
  db.prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, String(value));
}

// Seed once, on an empty database.
const kbCount = db.prepare('SELECT COUNT(*) AS c FROM kb').get().c;
if (kbCount === 0) {
  const insertKb = db.prepare('INSERT INTO kb (id, title, text) VALUES (?, ?, ?)');
  for (const k of KB) insertKb.run(k.id, k.title, k.text);
  insertKb.run('ASSET', 'Asset Management Policy (extract)', ASSET_POLICY);
}

const reqCount = db.prepare('SELECT COUNT(*) AS c FROM requests').get().c;
if (reqCount === 0) {
  const insertReq = db.prepare('INSERT INTO requests (id, name, email, date, text, initial, resolved) VALUES (?, ?, ?, ?, ?, ?, 0)');
  for (const r of SEED_REQUESTS) insertReq.run(r.id, r.name, r.email, r.date, r.text, r.initial);

  const insertTicket = db.prepare('INSERT INTO tickets (id, employee, issue, assigned, status, open, escalated, source_req, sources) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL)');
  for (const t of SEED_TICKETS) insertTicket.run(t.id, t.employee, t.issue, t.assigned, t.status, t.open, t.escalated);

  setMeta('nextTicketNum', FIRST_NEW_TICKET_NUM);
  setMeta('nextRequestNum', FIRST_NEW_REQUEST_NUM);
}

export function nextTicketId() {
  const n = parseInt(getMeta('nextTicketNum', FIRST_NEW_TICKET_NUM), 10);
  setMeta('nextTicketNum', n + 1);
  return `TK-${n}`;
}
export function nextRequestId() {
  const n = parseInt(getMeta('nextRequestNum', FIRST_NEW_REQUEST_NUM), 10);
  setMeta('nextRequestNum', n + 1);
  return `REQ-${String(n).padStart(2, '0')}`;
}

export default db;
