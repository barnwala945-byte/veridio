import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { existsSync } from 'node:fs';
import apiRouter from './routes.js';
import './db.js'; // ensures the DB is created + seeded before the server starts

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 4000;

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api', apiRouter);

// In production, serve the built React app (client/dist) from this same
// server, so the whole thing runs as one process on one port.
const clientDist = join(__dirname, '..', '..', 'client', 'dist');
if (existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(join(clientDist, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`Dispatch server listening on http://localhost:${PORT}`);
  if (!process.env.GEMINI_API_KEY) {
    console.warn('⚠ GEMINI_API_KEY is not set — copy server/.env.example to server/.env and add your key.');
  }
  if (!existsSync(clientDist)) {
    console.log('ℹ No client/dist found yet — run the client in dev mode (see README), or `npm run build` it for production.');
  }
});
