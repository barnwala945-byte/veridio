const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

/**
 * Calls the Google AI Studio (Gemini) generateContent API and returns the
 * parsed JSON object the model was asked to produce. Throws a plain
 * { code, message } error on any failure so the route handler can turn it
 * into a clean HTTP response.
 */
export async function callAgentJSON(prompt) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw { code: 'not_configured', message: 'GEMINI_API_KEY is not set. Copy server/.env.example to server/.env and add your key.' };
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`;

  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.2,
          responseMimeType: 'application/json',
        },
      }),
    });
  } catch (e) {
    throw { code: 'network_error', message: `Could not reach Google AI Studio: ${e.message}` };
  }

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw { code: 'upstream_error', message: `Gemini API error ${res.status}: ${body.slice(0, 400)}` };
  }

  const data = await res.json();

  const blockReason = data.promptFeedback?.blockReason;
  if (blockReason) {
    throw { code: 'blocked', message: `Gemini blocked this request (${blockReason}).` };
  }

  const parts = data.candidates?.[0]?.content?.parts || [];
  const text = parts.map((p) => p.text || '').join('').trim();
  if (!text) throw { code: 'empty_completion', message: 'Gemini returned no content.' };

  try {
    return JSON.parse(text);
  } catch {
    // responseMimeType:application/json should guarantee valid JSON, but
    // fall back to a loose extraction just in case of stray prose/fences.
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    const candidate = fence ? fence[1] : text;
    const start = candidate.search(/[{[]/);
    const end = Math.max(candidate.lastIndexOf('}'), candidate.lastIndexOf(']'));
    if (start >= 0 && end > start) {
      return JSON.parse(candidate.slice(start, end + 1));
    }
    throw { code: 'bad_json', message: 'Could not parse a JSON object from the model response.' };
  }
}
